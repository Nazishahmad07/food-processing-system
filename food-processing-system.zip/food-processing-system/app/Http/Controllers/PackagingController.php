<?php

namespace App\Http\Controllers;

use App\Models\Packaging;
use App\Models\FoodBatch;
use Illuminate\Http\Request;

class PackagingController extends Controller
{
    public function index()
    {
        $packagings = Packaging::latest()->paginate(10);
        return view('packagings.index', compact('packagings'));
    }

    public function create()
    {
        $batches = FoodBatch::all();
        return view('packagings.create', compact('batches'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'type' => 'required',
            'material' => 'required',
            'dimensions' => 'required',
            'capacity' => 'required|numeric',
            'batch_id' => 'required|exists:food_batches,id'
        ]);

        Packaging::create($validated);
        return redirect()->route('packagings.index')->with('success', 'Packaging created successfully.');
    }

    public function show(Packaging $packaging)
    {
        return view('packagings.show', compact('packaging'));
    }

    public function edit(Packaging $packaging)
    {
        $batches = FoodBatch::all();
        return view('packagings.edit', compact('packaging', 'batches'));
    }

    public function update(Request $request, Packaging $packaging)
    {
        $validated = $request->validate([
            'type' => 'required',
            'material' => 'required',
            'dimensions' => 'required',
            'capacity' => 'required|numeric',
            'batch_id' => 'required|exists:food_batches,id'
        ]);

        $packaging->update($validated);
        return redirect()->route('packagings.index')->with('success', 'Packaging updated successfully.');
    }

    public function destroy(Packaging $packaging)
    {
        $packaging->delete();
        return redirect()->route('packagings.index')->with('success', 'Packaging deleted successfully.');
    }

    public function inventory(Packaging $packaging)
    {
        $inventory = [
            'current_stock' => $packaging->quantity,
            'batch_info' => $packaging->foodBatch,
            'usage_history' => $packaging->usageHistory
        ];

        return view('packagings.inventory', compact('packaging', 'inventory'));
    }
}
