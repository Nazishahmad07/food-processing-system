<?php

namespace App\Http\Controllers;

use App\Models\Distribution;
use Illuminate\Http\Request;
use App\Models\FoodBatch;
class DistributionController extends Controller
{
    public function index()
    {
        $distributions = Distribution::latest()->paginate(10);
        return view('distributions.index', compact('distributions'));
    }

    public function create()
    {
        $batches = FoodBatch::all();
        return view('distributions.create', compact('batches'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'destination' => 'required',
            'quantity' => 'required|numeric',
            'shipping_date' => 'required|date',
            'delivery_date' => 'required|date|after:shipping_date',
            'batch_id' => 'required|exists:food_batches,id'
        ]);

        Distribution::create($validated);
        return redirect()->route('distributions.index')->with('success', 'Distribution record created successfully.');
    }

    public function show(Distribution $distribution)
    {
        return view('distributions.show', compact('distribution'));
    }

    public function edit(Distribution $distribution)
    {
        $batches = FoodBatch::all();
        return view('distributions.edit', compact('distribution', 'batches'));
    }

    public function update(Request $request, Distribution $distribution)
    {
        $validated = $request->validate([
            'destination' => 'required',
            'quantity' => 'required|numeric',
            'shipping_date' => 'required|date',
            'delivery_date' => 'required|date|after:shipping_date',
            'batch_id' => 'required|exists:food_batches,id'
        ]);

        $distribution->update($validated);
        return redirect()->route('distributions.index')->with('success', 'Distribution record updated successfully.');
    }

    public function destroy(Distribution $distribution)
    {
        $distribution->delete();
        return redirect()->route('distributions.index')->with('success', 'Distribution record deleted successfully.');
    }

    public function tracking(Distribution $distribution)
    {
        $trackingHistory = $distribution->trackingHistory()
                                      ->orderBy('timestamp', 'desc')
                                      ->get();
    
        return view('distributions.tracking', compact('distribution', 'trackingHistory'));
    }
    
    public function deliveryStatus(Distribution $distribution)
    {
        $status = [
            'current_location' => $distribution->currentLocation,
            'estimated_delivery' => $distribution->estimatedDeliveryTime,
            'status_updates' => $distribution->statusUpdates
        ];
    
        return view('distributions.status', compact('distribution', 'status'));
    }
    
    public function updates()
    {
        $updates = Distribution::with(['currentLocation', 'statusUpdates'])
                            ->where('status', 'in_transit')
                            ->get();
        return response()->json($updates);
    }
}
