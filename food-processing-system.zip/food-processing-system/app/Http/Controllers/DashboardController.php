<?php

namespace App\Http\Controllers;

use App\Models\FoodBatch;
use App\Models\Storage;
use App\Models\Distribution;

class DashboardController extends Controller
{
    public function index()
    {
        $totalBatches = FoodBatch::count();
        $activeStorages = Storage::where('status', '=', 'active')->count();  // Fixed the query
        $pendingDeliveries = Distribution::where('status', 'pending')->count();

        return view('dashboard.index', compact('totalBatches', 'activeStorages', 'pendingDeliveries'));
    }
}