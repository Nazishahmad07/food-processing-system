<?php

namespace App\Http\Controllers;

use App\Models\Storage;
use App\Models\FoodBatch;
use Illuminate\Http\Request;

class StorageController extends Controller
{
    public function index()
    {
        $storages = Storage::latest()->paginate(10);
        return view('storages.index', compact('storages'));
    }

    public function create()
    {
        $batches = FoodBatch::all();
        return view('storages.create', compact('batches'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'location' => 'required',
            'capacity' => 'required|numeric',
            'temperature' => 'required|numeric',
            'humidity' => 'required|numeric',
            'batch_id' => 'required|exists:food_batches,id'
        ]);

        Storage::create($validated);
        return redirect()->route('storages.index')->with('success', 'Storage record created successfully.');
    }

    public function show(Storage $storage)
    {
        return view('storages.show', compact('storage'));
    }

    public function edit(Storage $storage)
    {
        return view('storages.edit', compact('storage'));
    }

    public function update(Request $request, Storage $storage)
    {
        $validated = $request->validate([
            'location' => 'required',
            'capacity' => 'required|numeric',
            'temperature' => 'required|numeric',
            'humidity' => 'required|numeric',
            'batch_id' => 'required|exists:food_batches,id'
        ]);

        $storage->update($validated);
        return redirect()->route('storages.index')->with('success', 'Storage record updated successfully.');
    }

    public function destroy(Storage $storage)
    {
        $storage->delete();
        return redirect()->route('storages.index')->with('success', 'Storage record deleted successfully.');
    }

    public function temperatureLog(Storage $storage)
    {
        $temperatureLogs = $storage->temperatureLogs()
                                ->orderBy('recorded_at', 'desc')
                                ->get();
    
        return view('storages.temperature-log', compact('storage', 'temperatureLogs'));
    }
    
    public function humidityLog(Storage $storage)
    {
        $humidityLogs = $storage->humidityLogs()
                               ->orderBy('recorded_at', 'desc')
                               ->get();
    
        return view('storages.humidity-log', compact('storage', 'humidityLogs'));
    }
    
    public function status()
    {
        $storages = Storage::with('currentConditions')->get();
        return response()->json($storages);
    }
}
