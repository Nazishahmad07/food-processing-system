<?php

namespace App\Http\Controllers;

use App\Models\FoodBatch;
use Illuminate\Http\Request;

class FoodBatchController extends Controller
{
    public function index()
    {
        $batches = FoodBatch::latest()->paginate(10);
        return view('batches.index', compact('batches'));
    }

    public function create()
    {
        return view('batches.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'batch_number' => 'required|unique:food_batches',
            'name' => 'required',
            'category' => 'required',
            'product_name' => 'required',
            'quantity' => 'required|integer',
            'production_date' => 'required|date',
            'processing_date' => 'required|date',
            'quality_grade' => 'required',
            'expiry_date' => 'required|date|after:production_date'
        ]);

        FoodBatch::create($validated);
        return redirect()->route('batches.index')->with('success', 'Food batch created successfully.');
    }

    public function show(FoodBatch $batch)
    {
        return view('batches.show', compact('batch'));
    }

    public function edit(FoodBatch $batch)
    {
        return view('batches.edit', compact('batch'));
    }

    public function update(Request $request, FoodBatch $batch)
    {
        $validated = $request->validate([
            'batch_number' => 'required|unique:food_batches,batch_number,' . $batch->id,
            'name' => 'required',
            'category' => 'required',
            'product_name' => 'required',
            'quantity' => 'required|numeric',
            'production_date' => 'required|date',
            'processing_date' => 'required|date',
            'quality_grade' => 'required',
            'expiry_date' => 'required|date|after:production_date'
        ]);

        $batch->update($validated);
        return redirect()->route('batches.index')->with('success', 'Batch updated successfully.');
    }

    public function destroy(FoodBatch $batch)
    {
        $batch->delete();
        return redirect()->route('batches.index')->with('success', 'Batch deleted successfully.');
    }

    public function track(FoodBatch $batch)
    {
        $packaging = $batch->packaging;
        $storage = $batch->storage;
        $distributions = $batch->distributions;
    
        return view('batches.track', compact('batch', 'packaging', 'storage', 'distributions'));
    }
    
    public function generateReport(FoodBatch $batch)
    {
        $report = [
            'batch_info' => $batch,
            'packaging_details' => $batch->packaging,
            'storage_history' => $batch->storage,
            'distribution_status' => $batch->distributions
        ];
    
        return view('batches.report', compact('report'));
    }
    
    public function search(Request $request)
    {
        $query = $request->get('query');
        $batches = FoodBatch::where('batch_number', 'like', "%{$query}%")
                            ->orWhere('product_name', 'like', "%{$query}%")
                            ->get();
        return response()->json($batches);
    }
}
