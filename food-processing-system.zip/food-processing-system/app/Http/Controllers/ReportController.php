<?php

namespace App\Http\Controllers;

use App\Models\FoodBatch;
use App\Models\Distribution;
use App\Models\Storage;
use Carbon\Carbon;

class ReportController extends Controller
{
    public function daily()
    {
        $data = $this->generateReport('daily');
        return view('reports.daily', compact('data'));
    }

    public function weekly()
    {
        $data = $this->generateReport('weekly');
        return view('reports.weekly', compact('data'));
    }

    public function monthly()
    {
        $data = $this->generateReport('monthly');
        return view('reports.monthly', compact('data'));
    }

    public function custom(Request $request)
    {
        $startDate = $request->get('start_date');
        $endDate = $request->get('end_date');
        $data = $this->generateReport('custom', $startDate, $endDate);
        return view('reports.custom', compact('data'));
    }

    private function generateReport($type, $startDate = null, $endDate = null)
    {
        switch ($type) {
            case 'daily':
                $startDate = Carbon::today();
                $endDate = Carbon::tomorrow();
                break;
            case 'weekly':
                $startDate = Carbon::now()->startOfWeek();
                $endDate = Carbon::now()->endOfWeek();
                break;
            case 'monthly':
                $startDate = Carbon::now()->startOfMonth();
                $endDate = Carbon::now()->endOfMonth();
                break;
        }

        return [
            'batches' => FoodBatch::whereBetween('created_at', [$startDate, $endDate])->get(),
            'distributions' => Distribution::whereBetween('created_at', [$startDate, $endDate])->get(),
            'storage_usage' => Storage::whereBetween('created_at', [$startDate, $endDate])->get()
        ];
    }
}