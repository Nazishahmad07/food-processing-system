<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Storage extends Model
{
    use HasFactory;

    protected $fillable = [
        'location',
        'capacity',
        'temperature',
        'humidity',
        'batch_id'
    ];

    public function foodBatch()
    {
        return $this->belongsTo(FoodBatch::class, 'batch_id');
    }
}
