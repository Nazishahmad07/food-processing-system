<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Packaging extends Model
{
    use HasFactory;

    protected $fillable = [
        'type',
        'material',
        'dimensions',
        'capacity',
        'batch_id'
    ];

    public function foodBatch()
    {
        return $this->belongsTo(FoodBatch::class, 'batch_id');
    }
}
