<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FoodBatch extends Model
{
    protected $fillable = [
        'batch_number',
        'name',
        'category',
        'product_name',
        'quantity',
        'production_date',
        'processing_date',
        'quality_grade',
        'expiry_date'
    ];

    protected $dates = [
        'production_date',
        'processing_date',
        'expiry_date'
    ];

    public function packaging()
    {
        return $this->hasMany(Packaging::class, 'batch_id');
    }

    public function storage()
    {
        return $this->hasMany(Storage::class, 'batch_id');
    }

    public function distributions()
    {
        return $this->hasMany(Distribution::class, 'batch_id');
    }
}
