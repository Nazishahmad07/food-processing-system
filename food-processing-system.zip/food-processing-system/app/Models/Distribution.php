<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Distribution extends Model
{
    use HasFactory;

    protected $fillable = [
        'destination',
        'quantity',
        'shipping_date',
        'delivery_date',
        'batch_id'
    ];

    protected $casts = [
        'shipping_date' => 'datetime',
        'delivery_date' => 'datetime'
    ];

    public function foodBatch()
    {
        return $this->belongsTo(FoodBatch::class, 'batch_id');
    }
}
