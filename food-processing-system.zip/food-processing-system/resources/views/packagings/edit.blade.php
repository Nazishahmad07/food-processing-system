@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Edit Packaging</h1>

    <form action="{{ route('packagings.update', $packaging->id) }}" method="POST" class="max-w-lg">
        @csrf
        @method('PUT')
        
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Type</label>
            <input type="text" name="type" value="{{ $packaging->type }}" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Material</label>
            <input type="text" name="material" value="{{ $packaging->material }}" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Dimensions</label>
            <input type="text" name="dimensions" value="{{ $packaging->dimensions }}" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Capacity</label>
            <input type="number" step="0.01" name="capacity" value="{{ $packaging->capacity }}" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Batch</label>
            <select name="batch_id" class="w-full border rounded px-3 py-2" required>
                @foreach($batches as $batch)
                    <option value="{{ $batch->id }}" {{ $packaging->batch_id == $batch->id ? 'selected' : '' }}>
                        {{ $batch->batch_number }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="flex items-center">
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                Update Packaging
            </button>
            <a href="{{ route('packagings.index') }}" class="ml-2 text-gray-600 hover:text-gray-800">
                Cancel
            </a>
        </div>
    </form>
</div>
@endsection