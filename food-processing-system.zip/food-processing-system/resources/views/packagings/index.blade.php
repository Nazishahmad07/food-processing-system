@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Packaging List</h1>
    <a href="{{ route('packagings.create') }}" class="bg-blue-500 text-white px-4 py-2 rounded">Add New Packaging</a>
    
    <table class="w-full mt-4 bg-white shadow-lg rounded-lg">
        <thead>
            <tr>
                <th class="px-4 py-2">Type</th>
                <th class="px-4 py-2">Material</th>
                <th class="px-4 py-2">Dimensions</th>
                <th class="px-4 py-2">Capacity</th>
                <th class="px-4 py-2">Batch</th>
                <th class="px-4 py-2">Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($packagings as $packaging)
            <tr>
                <td class="border px-4 py-2">{{ $packaging->type }}</td>
                <td class="border px-4 py-2">{{ $packaging->material }}</td>
                <td class="border px-4 py-2">{{ $packaging->dimensions }}</td>
                <td class="border px-4 py-2">{{ $packaging->capacity }}</td>
                <td class="border px-4 py-2">{{ $packaging->foodBatch->batch_number }}</td>
                <td class="border px-4 py-2">
                    <a href="{{ route('packagings.edit', $packaging->id) }}" class="text-blue-600">Edit</a>
                    <form action="{{ route('packagings.destroy', $packaging->id) }}" method="POST" class="inline">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="text-red-600 ml-2">Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection