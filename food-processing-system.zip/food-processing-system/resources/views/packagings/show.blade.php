@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Packaging Details</h1>
    
    <div class="bg-white shadow rounded-lg p-6">
        <div class="mb-4">
            <label class="font-bold">Type:</label>
            <p>{{ $packaging->type }}</p>
        </div>
        
        <div class="mb-4">
            <label class="font-bold">Material:</label>
            <p>{{ $packaging->material }}</p>
        </div>
        
        <div class="mb-4">
            <label class="font-bold">Dimensions:</label>
            <p>{{ $packaging->dimensions }}</p>
        </div>
        
        <div class="mb-4">
            <label class="font-bold">Capacity:</label>
            <p>{{ $packaging->capacity }}</p>
        </div>
        
        <div class="mb-4">
            <label class="font-bold">Batch Number:</label>
            <p>{{ $packaging->foodBatch->batch_number }}</p>
        </div>
        
        <div class="mt-6">
            <a href="{{ route('packagings.edit', $packaging->id) }}" class="bg-blue-500 text-white px-4 py-2 rounded">Edit</a>
            <a href="{{ route('packagings.index') }}" class="ml-2 bg-gray-500 text-white px-4 py-2 rounded">Back</a>
        </div>
    </div>
</div>
@endsection