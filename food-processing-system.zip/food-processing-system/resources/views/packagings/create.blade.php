@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Create New Packaging</h1>
    
    <form action="{{ route('packagings.store') }}" method="POST" class="max-w-lg">
        @csrf
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Type</label>
            <input type="text" name="type" class="w-full border rounded px-3 py-2" required>
        </div>
        
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Material</label>
            <input type="text" name="material" class="w-full border rounded px-3 py-2" required>
        </div>
        
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Dimensions</label>
            <input type="text" name="dimensions" class="w-full border rounded px-3 py-2" required>
        </div>
        
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Capacity</label>
            <input type="number" name="capacity" class="w-full border rounded px-3 py-2" required>
        </div>
        
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Batch</label>
            <select name="batch_id" class="w-full border rounded px-3 py-2" required>
                @foreach($batches as $batch)
                    <option value="{{ $batch->id }}">{{ $batch->batch_number }}</option>
                @endforeach
            </select>
        </div>
        
        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Create Packaging</button>
    </form>
</div>
@endsection