@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Create New Distribution</h1>

    <form action="{{ route('distributions.store') }}" method="POST" class="max-w-lg">
        @csrf
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Destination</label>
            <input type="text" name="destination" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Quantity</label>
            <input type="number" name="quantity" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Shipping Date</label>
            <input type="datetime-local" name="shipping_date" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Delivery Date</label>
            <input type="datetime-local" name="delivery_date" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Status</label>
            <select name="status" class="w-full border rounded px-3 py-2" required>
                <option value="pending">Pending</option>
                <option value="in_transit">In Transit</option>
                <option value="delivered">Delivered</option>
            </select>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Batch</label>
            <select name="batch_id" class="w-full border rounded px-3 py-2" required>
                @foreach($batches as $batch)
                    <option value="{{ $batch->id }}">{{ $batch->batch_number }}</option>
                @endforeach
            </select>
        </div>

        <div class="flex items-center">
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                Create Distribution
            </button>
            <a href="{{ route('distributions.index') }}" class="ml-2 text-gray-600 hover:text-gray-800">
                Cancel
            </a>
        </div>
    </form>
</div>
@endsection