@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-6">Dashboard</h1>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <!-- Batches Card -->
        <div class="bg-white rounded-lg shadow-lg p-6">
            <h2 class="text-xl font-semibold mb-4">Food Batches</h2>
            <div class="text-3xl font-bold mb-2">{{ \App\Models\FoodBatch::count() }}</div>
            <p class="text-gray-600 mb-4">Total batches in system</p>
            <div class="flex space-x-2">
                <a href="{{ route('batches.index') }}" class="text-blue-500 hover:text-blue-700">View</a>
                <a href="{{ route('batches.create') }}" class="text-green-500 hover:text-green-700">Add</a>
            </div>
        </div>

        <!-- Packaging Card -->
        <div class="bg-white rounded-lg shadow-lg p-6">
            <h2 class="text-xl font-semibold mb-4">Packaging</h2>
            <div class="text-3xl font-bold mb-2">{{ \App\Models\Packaging::count() }}</div>
            <p class="text-gray-600 mb-4">Total packaging records</p>
            <div class="flex space-x-2">
                <a href="{{ route('packagings.index') }}" class="text-blue-500 hover:text-blue-700">View</a>
                <a href="{{ route('packagings.create') }}" class="text-green-500 hover:text-green-700">Add</a>
            </div>
        </div>

        <!-- Storage Card -->
        <div class="bg-white rounded-lg shadow-lg p-6">
            <h2 class="text-xl font-semibold mb-4">Storage</h2>
            <div class="text-3xl font-bold mb-2">{{ \App\Models\Storage::count() }}</div>
            <p class="text-gray-600 mb-4">Total storage locations</p>
            <div class="flex space-x-2">
                <a href="{{ route('storages.index') }}" class="text-blue-500 hover:text-blue-700">View</a>
                <a href="{{ route('storages.create') }}" class="text-green-500 hover:text-green-700">Add</a>
            </div>
        </div>

        <!-- Distribution Card -->
        <div class="bg-white rounded-lg shadow-lg p-6">
            <h2 class="text-xl font-semibold mb-4">Distribution</h2>
            <div class="text-3xl font-bold mb-2">{{ \App\Models\Distribution::count() }}</div>
            <p class="text-gray-600 mb-4">Total distributions</p>
            <div class="flex space-x-2">
                <a href="{{ route('distributions.index') }}" class="text-blue-500 hover:text-blue-700">View</a>
                <a href="{{ route('distributions.create') }}" class="text-green-500 hover:text-green-700">Add</a>
            </div>
        </div>
    </div>

    <!-- Recent Batches Table -->
    <div class="mt-8">
        <h2 class="text-xl font-semibold mb-4">Recent Batches</h2>
        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
            <table class="w-full">
                <thead>
                    <tr class="bg-gray-50">
                        <th class="px-4 py-2 text-left">Batch Number</th>
                        <th class="px-4 py-2 text-left">Name</th>
                        <th class="px-4 py-2 text-left">Category</th>
                        <th class="px-4 py-2 text-left">Quality Grade</th>
                        <th class="px-4 py-2 text-left">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach(\App\Models\FoodBatch::latest()->take(5)->get() as $batch)
                    <tr class="border-t">
                        <td class="px-4 py-2">{{ $batch->batch_number }}</td>
                        <td class="px-4 py-2">{{ $batch->name }}</td>
                        <td class="px-4 py-2">{{ $batch->category }}</td>
                        <td class="px-4 py-2">{{ $batch->quality_grade }}</td>
                        <td class="px-4 py-2">
                            <div class="flex space-x-2">
                                <a href="{{ route('batches.show', $batch) }}" 
                                   class="text-blue-600 hover:text-blue-800">View</a>
                                <a href="{{ route('batches.edit', $batch) }}" 
                                   class="text-green-600 hover:text-green-800">Edit</a>
                                <form action="{{ route('batches.destroy', $batch) }}" 
                                      method="POST" class="inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" 
                                            class="text-red-600 hover:text-red-800"
                                            onclick="return confirm('Are you sure you want to delete this batch?')">
                                        Delete
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection