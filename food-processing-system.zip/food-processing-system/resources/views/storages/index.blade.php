@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Storage Management</h1>
    <a href="{{ route('storages.create') }}" class="bg-blue-500 text-white px-4 py-2 rounded">Add New Storage</a>

    <div class="mt-6">
        <table class="w-full bg-white shadow-lg rounded-lg">
            <thead>
                <tr>
                    <th class="px-4 py-2 text-left">Location</th>
                    <th class="px-4 py-2 text-left">Capacity</th>
                    <th class="px-4 py-2 text-left">Temperature (°C)</th>
                    <th class="px-4 py-2 text-left">Humidity (%)</th>
                    <th class="px-4 py-2 text-left">Status</th>
                    <th class="px-4 py-2 text-left">Batch</th>
                    <th class="px-4 py-2 text-left">Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($storages as $storage)
                <tr class="border-t">
                    <td class="px-4 py-2">{{ $storage->location }}</td>
                    <td class="px-4 py-2">{{ $storage->capacity }}</td>
                    <td class="px-4 py-2">{{ $storage->temperature }}</td>
                    <td class="px-4 py-2">{{ $storage->humidity }}</td>
                    <td class="px-4 py-2">
                        <span class="px-2 py-1 rounded text-sm 
                            @if($storage->status == 'active') bg-green-100 text-green-800
                            @else bg-red-100 text-red-800
                            @endif">
                            {{ ucfirst($storage->status) }}
                        </span>
                    </td>
                    <td class="px-4 py-2">{{ $storage->foodBatch->batch_number }}</td>
                    <td class="px-4 py-2">
                        <div class="flex space-x-2">
                            <a href="{{ route('storages.show', $storage->id) }}" 
                               class="text-blue-600 hover:text-blue-800">View</a>
                            <a href="{{ route('storages.edit', $storage->id) }}" 
                               class="text-green-600 hover:text-green-800">Edit</a>
                            <form action="{{ route('storages.destroy', $storage->id) }}" 
                                  method="POST" class="inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" 
                                        class="text-red-600 hover:text-red-800"
                                        onclick="return confirm('Are you sure you want to delete this storage?')">
                                    Delete
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection