@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Add New Storage</h1>

    <form action="{{ route('storages.store') }}" method="POST" class="max-w-lg">
        @csrf
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Location</label>
            <input type="text" name="location" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Capacity</label>
            <input type="number" step="0.01" name="capacity" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Temperature (°C)</label>
            <input type="number" step="0.1" name="temperature" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Humidity (%)</label>
            <input type="number" step="0.1" name="humidity" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Status</label>
            <select name="status" class="w-full border rounded px-3 py-2" required>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Batch</label>
            <select name="batch_id" class="w-full border rounded px-3 py-2" required>
                @foreach($batches as $batch)
                    <option value="{{ $batch->id }}">{{ $batch->batch_number }}</option>
                @endforeach
            </select>
        </div>

        <div class="flex items-center">
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                Create Storage
            </button>
            <a href="{{ route('storages.index') }}" class="ml-2 text-gray-600 hover:text-gray-800">
                Cancel
            </a>
        </div>
    </form>
</div>
@endsection