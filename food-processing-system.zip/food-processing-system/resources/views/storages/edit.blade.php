@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Edit Storage Location</h1>

    <form action="{{ route('storages.update', $storage->id) }}" method="POST" class="max-w-lg">
        @csrf
        @method('PUT')

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Location</label>
            <input type="text" name="location" value="{{ $storage->location }}" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Temperature</label>
            <input type="number" name="temperature" value="{{ $storage->temperature }}" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Batch</label>
            <select name="food_batch_id" class="w-full border rounded px-3 py-2" required>
                @foreach($batches as $batch)
                    <option value="{{ $batch->id }}" {{ $storage->food_batch_id == $batch->id ? 'selected' : '' }}>
                        {{ $batch->batch_number }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Stored On</label>
            <input type="date" name="stored_on" value="{{ $storage->stored_on }}" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="flex items-center">
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                Update Storage
            </button>
            <a href="{{ route('storages.index') }}" class="ml-2 text-gray-600 hover:text-gray-800">
                Cancel
            </a>
        </div>
    </form>
</div>
@endsection