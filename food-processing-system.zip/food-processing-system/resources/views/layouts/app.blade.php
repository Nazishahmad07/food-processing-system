<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Processing System</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <nav class="bg-white shadow-lg">
        <div class="container mx-auto px-6 py-3">
            <div class="flex items-center justify-between">
                <div class="text-xl font-semibold">
                    <a href="/" class="text-gray-800">Food Processing System</a>
                </div>
                <div class="space-x-4">
                    <a href="{{ route('batches.index') }}" class="text-gray-800">Batches</a>
                    <a href="{{ route('packagings.index') }}" class="text-gray-800">Packaging</a>
                    <a href="{{ route('storages.index') }}" class="text-gray-800">Storage</a>
                    <a href="{{ route('distributions.index') }}" class="text-gray-800">Distribution</a>
                </div>
            </div>
        </div>
    </nav>

    <main class="py-8">
        @yield('content')
    </main>
</body>
</html>