@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Edit Batch</h1>
    
    <form action="{{ route('batches.update', $batch->id) }}" method="POST" class="max-w-lg">
        @csrf
        @method('PUT')
        
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Batch Number</label>
            <input type="text" name="batch_number" value="{{ $batch->batch_number }}" class="w-full border rounded px-3 py-2" required>
        </div>
        
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Product Name</label>
            <input type="text" name="product_name" value="{{ $batch->product_name }}" class="w-full border rounded px-3 py-2" required>
        </div>
        
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Quantity</label>
            <input type="number" name="quantity" value="{{ $batch->quantity }}" class="w-full border rounded px-3 py-2" required>
        </div>
        
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Production Date</label>
            <input type="date" name="production_date" value="{{ $batch->production_date->format('Y-m-d') }}" class="w-full border rounded px-3 py-2" required>
        </div>
        
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Expiry Date</label>
            <input type="date" name="expiry_date" value="{{ $batch->expiry_date->format('Y-m-d') }}" class="w-full border rounded px-3 py-2" required>
        </div>
        
        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Update Batch</button>
    </form>
</div>
@endsection