@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Batch Details</h1>
    
    <div class="bg-white shadow rounded-lg p-6">
        <div class="mb-4">
            <label class="font-bold">Batch Number:</label>
            <p>{{ $batch->batch_number }}</p>
        </div>
        
        <div class="mb-4">
            <label class="font-bold">Product Name:</label>
            <p>{{ $batch->product_name }}</p>
        </div>
        
        <div class="mb-4">
            <label class="font-bold">Quantity:</label>
            <p>{{ $batch->quantity }}</p>
        </div>
        
        <div class="mb-4">
            <label class="font-bold">Production Date:</label>
            <p>{{ $batch->production_date->format('Y-m-d') }}</p>
        </div>
        
        <div class="mb-4">
            <label class="font-bold">Expiry Date:</label>
            <p>{{ $batch->expiry_date->format('Y-m-d') }}</p>
        </div>
        
        <div class="mt-6">
            <a href="{{ route('batches.edit', $batch->id) }}" class="bg-blue-500 text-white px-4 py-2 rounded">Edit</a>
            <a href="{{ route('batches.index') }}" class="ml-2 bg-gray-500 text-white px-4 py-2 rounded">Back</a>
        </div>
    </div>
</div>
@endsection