@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Create New Food Batch</h1>

    <form action="{{ route('batches.store') }}" method="POST" class="max-w-lg">
        @csrf
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Batch Number</label>
            <input type="text" name="batch_number" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Name</label>
            <input type="text" name="name" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Category</label>
            <select name="category" class="w-full border rounded px-3 py-2" required>
                <option value="">Select Category</option>
                <option value="raw">Raw Materials</option>
                <option value="processed">Processed Food</option>
                <option value="packaged">Packaged Products</option>
                <option value="finished">Finished Goods</option>
            </select>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Product Name</label>
            <input type="text" name="product_name" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Quantity</label>
            <input type="number" name="quantity" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Production Date</label>
            <input type="datetime-local" name="production_date" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Processing Date</label>
            <input type="datetime-local" name="processing_date" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Quality Grade</label>
            <select name="quality_grade" class="w-full border rounded px-3 py-2" required>
                <option value="">Select Grade</option>
                <option value="A">Grade A</option>
                <option value="B">Grade B</option>
                <option value="C">Grade C</option>
            </select>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Expiry Date</label>
            <input type="datetime-local" name="expiry_date" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="flex items-center">
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                Create Batch
            </button>
            <a href="{{ route('batches.index') }}" class="ml-2 text-gray-600 hover:text-gray-800">
                Cancel
            </a>
        </div>
    </form>
</div>
@endsection