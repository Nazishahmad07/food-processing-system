@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Food Batches</h1>
    <a href="{{ route('batches.create') }}" class="bg-blue-500 text-white px-4 py-2 rounded">Add New Batch</a>

    <div class="mt-6">
        <table class="w-full bg-white shadow-lg rounded-lg">
            <thead>
                <tr>
                    <th class="px-4 py-2 text-left">Batch Number</th>
                    <th class="px-4 py-2 text-left">Name</th>
                    <th class="px-4 py-2 text-left">Category</th>
                    <th class="px-4 py-2 text-left">Product Name</th>
                    <th class="px-4 py-2 text-left">Quantity</th>
                    <th class="px-4 py-2 text-left">Processing Date</th>
                    <th class="px-4 py-2 text-left">Quality Grade</th>
                    <th class="px-4 py-2 text-left">Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($batches as $batch)
                <tr class="border-t">
                    <td class="px-4 py-2">{{ $batch->batch_number }}</td>
                    <td class="px-4 py-2">{{ $batch->name }}</td>
                    <td class="px-4 py-2">{{ $batch->category }}</td>
                    <td class="px-4 py-2">{{ $batch->product_name }}</td>
                    <td class="px-4 py-2">{{ $batch->quantity }}</td>
                    <td class="px-4 py-2">{{ $batch->processing_date->format('Y-m-d') }}</td>
                    <td class="px-4 py-2">{{ $batch->quality_grade }}</td>
                    <td class="px-4 py-2">
                        <div class="flex space-x-2">
                            <a href="{{ route('batches.show', $batch->id) }}" 
                               class="text-blue-600 hover:text-blue-800">View</a>
                            <a href="{{ route('batches.edit', $batch->id) }}" 
                               class="text-green-600 hover:text-green-800">Edit</a>
                            <form action="{{ route('batches.destroy', $batch->id) }}" 
                                  method="POST" class="inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" 
                                        class="text-red-600 hover:text-red-800"
                                        onclick="return confirm('Are you sure you want to delete this batch?')">
                                    Delete
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>

        <div class="mt-4">
            {{ $batches->links() }}
        </div>
    </div>
</div>
@endsection
