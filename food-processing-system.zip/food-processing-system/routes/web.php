<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FoodBatchController;
use App\Http\Controllers\PackagingController;
use App\Http\Controllers\StorageController;
use App\Http\Controllers\DistributionController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ReportController;

// Dashboard
Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

// Food Batches
Route::resource('batches', FoodBatchController::class);
Route::resource('packagings', PackagingController::class);
Route::resource('storages', StorageController::class)->parameters([
    'storages' => 'storage'
]);
Route::get('storages/{storage}/edit', [StorageController::class, 'edit'])->name('storages.edit');
Route::put('storages/{storage}', [StorageController::class, 'update'])->name('storages.update');
Route::resource('distributions', DistributionController::class);

// Reports and Analytics
Route::prefix('reports')->group(function () {
    Route::get('daily', [ReportController::class, 'daily'])->name('reports.daily');
    Route::get('weekly', [ReportController::class, 'weekly'])->name('reports.weekly');
    Route::get('monthly', [ReportController::class, 'monthly'])->name('reports.monthly');
    Route::get('custom', [ReportController::class, 'custom'])->name('reports.custom');
});

// API Routes for AJAX requests
Route::prefix('api')->group(function () {
    Route::get('batches/search', [FoodBatchController::class, 'search'])->name('api.batches.search');
    Route::get('storage/status', [StorageController::class, 'status'])->name('api.storage.status');
    Route::get('distribution/updates', [DistributionController::class, 'updates'])->name('api.distribution.updates');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
