

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Packaging List</h1>
    <a href="<?php echo e(route('packagings.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded">Add New Packaging</a>
    
    <table class="w-full mt-4 bg-white shadow-lg rounded-lg">
        <thead>
            <tr>
                <th class="px-4 py-2">Type</th>
                <th class="px-4 py-2">Material</th>
                <th class="px-4 py-2">Dimensions</th>
                <th class="px-4 py-2">Capacity</th>
                <th class="px-4 py-2">Batch</th>
                <th class="px-4 py-2">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $packagings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $packaging): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="border px-4 py-2"><?php echo e($packaging->type); ?></td>
                <td class="border px-4 py-2"><?php echo e($packaging->material); ?></td>
                <td class="border px-4 py-2"><?php echo e($packaging->dimensions); ?></td>
                <td class="border px-4 py-2"><?php echo e($packaging->capacity); ?></td>
                <td class="border px-4 py-2"><?php echo e($packaging->foodBatch->batch_number); ?></td>
                <td class="border px-4 py-2">
                    <a href="<?php echo e(route('packagings.edit', $packaging->id)); ?>" class="text-blue-600">Edit</a>
                    <form action="<?php echo e(route('packagings.destroy', $packaging->id)); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="text-red-600 ml-2">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pavilion\food-processing-system\resources\views/packagings/index.blade.php ENDPATH**/ ?>