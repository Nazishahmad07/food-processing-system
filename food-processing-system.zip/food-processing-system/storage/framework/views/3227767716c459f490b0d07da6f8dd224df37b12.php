

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Edit Batch</h1>
    
    <form action="<?php echo e(route('batches.update', $batch->id)); ?>" method="POST" class="max-w-lg">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Batch Number</label>
            <input type="text" name="batch_number" value="<?php echo e($batch->batch_number); ?>" class="w-full border rounded px-3 py-2" required>
        </div>
        
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Product Name</label>
            <input type="text" name="product_name" value="<?php echo e($batch->product_name); ?>" class="w-full border rounded px-3 py-2" required>
        </div>
        
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Quantity</label>
            <input type="number" name="quantity" value="<?php echo e($batch->quantity); ?>" class="w-full border rounded px-3 py-2" required>
        </div>
        
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Production Date</label>
            <input type="date" name="production_date" value="<?php echo e($batch->production_date->format('Y-m-d')); ?>" class="w-full border rounded px-3 py-2" required>
        </div>
        
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Expiry Date</label>
            <input type="date" name="expiry_date" value="<?php echo e($batch->expiry_date->format('Y-m-d')); ?>" class="w-full border rounded px-3 py-2" required>
        </div>
        
        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Update Batch</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pavilion\food-processing-system\resources\views/batches/edit.blade.php ENDPATH**/ ?>