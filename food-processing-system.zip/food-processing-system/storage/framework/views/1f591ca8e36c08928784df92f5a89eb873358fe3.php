

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Add New Storage</h1>

    <form action="<?php echo e(route('storages.store')); ?>" method="POST" class="max-w-lg">
        <?php echo csrf_field(); ?>
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Location</label>
            <input type="text" name="location" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Capacity</label>
            <input type="number" step="0.01" name="capacity" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Temperature (°C)</label>
            <input type="number" step="0.1" name="temperature" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Humidity (%)</label>
            <input type="number" step="0.1" name="humidity" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Status</label>
            <select name="status" class="w-full border rounded px-3 py-2" required>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Batch</label>
            <select name="batch_id" class="w-full border rounded px-3 py-2" required>
                <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($batch->id); ?>"><?php echo e($batch->batch_number); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="flex items-center">
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                Create Storage
            </button>
            <a href="<?php echo e(route('storages.index')); ?>" class="ml-2 text-gray-600 hover:text-gray-800">
                Cancel
            </a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pavilion\food-processing-system\resources\views/storages/create.blade.php ENDPATH**/ ?>