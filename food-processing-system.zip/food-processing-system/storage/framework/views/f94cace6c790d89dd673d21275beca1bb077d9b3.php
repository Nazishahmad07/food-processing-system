

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Batch Details</h1>
    
    <div class="bg-white shadow rounded-lg p-6">
        <div class="mb-4">
            <label class="font-bold">Batch Number:</label>
            <p><?php echo e($batch->batch_number); ?></p>
        </div>
        
        <div class="mb-4">
            <label class="font-bold">Product Name:</label>
            <p><?php echo e($batch->product_name); ?></p>
        </div>
        
        <div class="mb-4">
            <label class="font-bold">Quantity:</label>
            <p><?php echo e($batch->quantity); ?></p>
        </div>
        
        <div class="mb-4">
            <label class="font-bold">Production Date:</label>
            <p><?php echo e($batch->production_date->format('Y-m-d')); ?></p>
        </div>
        
        <div class="mb-4">
            <label class="font-bold">Expiry Date:</label>
            <p><?php echo e($batch->expiry_date->format('Y-m-d')); ?></p>
        </div>
        
        <div class="mt-6">
            <a href="<?php echo e(route('batches.edit', $batch->id)); ?>" class="bg-blue-500 text-white px-4 py-2 rounded">Edit</a>
            <a href="<?php echo e(route('batches.index')); ?>" class="ml-2 bg-gray-500 text-white px-4 py-2 rounded">Back</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pavilion\food-processing-system\resources\views/batches/show.blade.php ENDPATH**/ ?>