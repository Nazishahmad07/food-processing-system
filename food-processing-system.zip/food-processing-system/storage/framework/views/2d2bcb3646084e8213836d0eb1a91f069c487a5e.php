

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Edit Distribution</h1>

    <form action="<?php echo e(route('distributions.update', $distribution->id)); ?>" method="POST" class="max-w-lg">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Destination</label>
            <input type="text" name="destination" value="<?php echo e($distribution->destination); ?>" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Quantity</label>
            <input type="number" name="quantity" value="<?php echo e($distribution->quantity); ?>" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Shipping Date</label>
            <input type="datetime-local" name="shipping_date" value="<?php echo e(date('Y-m-d\TH:i', strtotime($distribution->shipping_date))); ?>" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Delivery Date</label>
            <input type="datetime-local" name="delivery_date" value="<?php echo e(date('Y-m-d\TH:i', strtotime($distribution->delivery_date))); ?>" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Status</label>
            <select name="status" class="w-full border rounded px-3 py-2" required>
                <option value="pending" <?php echo e($distribution->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                <option value="in_transit" <?php echo e($distribution->status == 'in_transit' ? 'selected' : ''); ?>>In Transit</option>
                <option value="delivered" <?php echo e($distribution->status == 'delivered' ? 'selected' : ''); ?>>Delivered</option>
            </select>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Batch</label>
            <select name="batch_id" class="w-full border rounded px-3 py-2" required>
                <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($batch->id); ?>" <?php echo e($distribution->batch_id == $batch->id ? 'selected' : ''); ?>>
                        <?php echo e($batch->batch_number); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="flex items-center">
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                Update Distribution
            </button>
            <a href="<?php echo e(route('distributions.index')); ?>" class="ml-2 text-gray-600 hover:text-gray-800">
                Cancel
            </a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pavilion\food-processing-system\resources\views/distributions/edit.blade.php ENDPATH**/ ?>