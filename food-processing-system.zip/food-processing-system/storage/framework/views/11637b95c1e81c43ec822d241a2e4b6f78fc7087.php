

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Distribution Details</h1>

    <div class="bg-white rounded-lg shadow-lg p-6 max-w-lg">
        <div class="mb-4">
            <label class="font-semibold text-gray-700">Batch Number:</label>
            <p class="mt-1"><?php echo e($distribution->foodBatch->batch_number); ?></p>
        </div>

        <div class="mb-4">
            <label class="font-semibold text-gray-700">Destination:</label>
            <p class="mt-1"><?php echo e($distribution->destination); ?></p>
        </div>

        <div class="mb-4">
            <label class="font-semibold text-gray-700">Distribution Date:</label>
            <p class="mt-1"><?php echo e(date('Y-m-d', strtotime($distribution->distribution_date))); ?></p>
        </div>

        <div class="mb-4">
            <label class="font-semibold text-gray-700">Quantity:</label>
            <p class="mt-1"><?php echo e($distribution->quantity); ?></p>
        </div>

        <div class="mt-6 flex space-x-2">
            <a href="<?php echo e(route('distributions.edit', $distribution->id)); ?>" 
               class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Edit</a>
            <a href="<?php echo e(route('distributions.index')); ?>" 
               class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">Back to List</a>
            <form action="<?php echo e(route('distributions.destroy', $distribution->id)); ?>" method="POST" class="inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" 
                        class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
                        onclick="return confirm('Are you sure you want to delete this distribution record?')">
                    Delete
                </button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pavilion\food-processing-system\resources\views/distributions/show.blade.php ENDPATH**/ ?>