

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Edit Storage Location</h1>

    <form action="<?php echo e(route('storages.update', $storage->id)); ?>" method="POST" class="max-w-lg">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Location</label>
            <input type="text" name="location" value="<?php echo e($storage->location); ?>" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Temperature</label>
            <input type="number" name="temperature" value="<?php echo e($storage->temperature); ?>" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Batch</label>
            <select name="food_batch_id" class="w-full border rounded px-3 py-2" required>
                <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($batch->id); ?>" <?php echo e($storage->food_batch_id == $batch->id ? 'selected' : ''); ?>>
                        <?php echo e($batch->batch_number); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">Stored On</label>
            <input type="date" name="stored_on" value="<?php echo e($storage->stored_on); ?>" class="w-full border rounded px-3 py-2" required>
        </div>

        <div class="flex items-center">
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                Update Storage
            </button>
            <a href="<?php echo e(route('storages.index')); ?>" class="ml-2 text-gray-600 hover:text-gray-800">
                Cancel
            </a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pavilion\food-processing-system\resources\views/storages/edit.blade.php ENDPATH**/ ?>