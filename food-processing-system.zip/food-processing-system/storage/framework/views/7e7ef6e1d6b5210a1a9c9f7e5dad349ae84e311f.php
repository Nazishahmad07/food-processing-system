

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Distribution Management</h1>
    <a href="<?php echo e(route('distributions.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded">Add New Distribution</a>

    <div class="mt-6">
        <table class="w-full bg-white shadow-lg rounded-lg">
            <thead>
                <tr>
                    <th class="px-4 py-2 text-left">Destination</th>
                    <th class="px-4 py-2 text-left">Quantity</th>
                    <th class="px-4 py-2 text-left">Shipping Date</th>
                    <th class="px-4 py-2 text-left">Delivery Date</th>
                    <th class="px-4 py-2 text-left">Status</th>
                    <th class="px-4 py-2 text-left">Batch</th>
                    <th class="px-4 py-2 text-left">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $distributions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distribution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-t">
                    <td class="px-4 py-2"><?php echo e($distribution->destination); ?></td>
                    <td class="px-4 py-2"><?php echo e($distribution->quantity); ?></td>
                    <td class="px-4 py-2"><?php echo e($distribution->shipping_date->format('Y-m-d')); ?></td>
                    <td class="px-4 py-2"><?php echo e($distribution->delivery_date->format('Y-m-d')); ?></td>
                    <td class="px-4 py-2">
                        <span class="px-2 py-1 rounded text-sm 
                            <?php if($distribution->status == 'pending'): ?> bg-yellow-100 text-yellow-800
                            <?php elseif($distribution->status == 'in_transit'): ?> bg-blue-100 text-blue-800
                            <?php else: ?> bg-green-100 text-green-800
                            <?php endif; ?>">
                            <?php echo e(ucfirst($distribution->status)); ?>

                        </span>
                    </td>
                    <td class="px-4 py-2"><?php echo e($distribution->foodBatch->batch_number); ?></td>
                    <td class="px-4 py-2">
                        <div class="flex space-x-2">
                            <a href="<?php echo e(route('distributions.show', $distribution->id)); ?>" 
                               class="text-blue-600 hover:text-blue-800">View</a>
                            <a href="<?php echo e(route('distributions.edit', $distribution->id)); ?>" 
                               class="text-green-600 hover:text-green-800">Edit</a>
                            <form action="<?php echo e(route('distributions.destroy', $distribution->id)); ?>" 
                                  method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" 
                                        class="text-red-600 hover:text-red-800"
                                        onclick="return confirm('Are you sure you want to delete this distribution?')">
                                    Delete
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pavilion\food-processing-system\resources\views/distributions/index.blade.php ENDPATH**/ ?>