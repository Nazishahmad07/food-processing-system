

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-6">Dashboard</h1>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Total Batches Card -->
        <div class="bg-white rounded-lg shadow p-6">
            <h2 class="text-lg font-semibold text-gray-700">Total Batches</h2>
            <p class="text-3xl font-bold text-blue-600"><?php echo e($totalBatches); ?></p>
        </div>

        <!-- Active Storages Card -->
        <div class="bg-white rounded-lg shadow p-6">
            <h2 class="text-lg font-semibold text-gray-700">Active Storages</h2>
            <p class="text-3xl font-bold text-green-600"><?php echo e($activeStorages); ?></p>
        </div>

        <!-- Pending Deliveries Card -->
        <div class="bg-white rounded-lg shadow p-6">
            <h2 class="text-lg font-semibold text-gray-700">Pending Deliveries</h2>
            <p class="text-3xl font-bold text-orange-600"><?php echo e($pendingDeliveries); ?></p>
        </div>
    </div>

    <div class="mt-8">
        <h2 class="text-xl font-semibold mb-4">Quick Actions</h2>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <a href="<?php echo e(route('batches.create')); ?>" class="bg-blue-500 text-white rounded-lg p-4 text-center hover:bg-blue-600">
                New Batch
            </a>
            <a href="<?php echo e(route('packagings.create')); ?>" class="bg-green-500 text-white rounded-lg p-4 text-center hover:bg-green-600">
                New Packaging
            </a>
            <a href="<?php echo e(route('storages.create')); ?>" class="bg-purple-500 text-white rounded-lg p-4 text-center hover:bg-purple-600">
                New Storage
            </a>
            <a href="<?php echo e(route('distributions.create')); ?>" class="bg-orange-500 text-white rounded-lg p-4 text-center hover:bg-orange-600">
                New Distribution
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pavilion\food-processing-system\resources\views/dashboard/index.blade.php ENDPATH**/ ?>