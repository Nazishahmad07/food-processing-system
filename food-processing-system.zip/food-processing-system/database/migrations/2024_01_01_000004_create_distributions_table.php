<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('distributions', function (Blueprint $table) {
            $table->id();
            $table->string('destination');
            $table->integer('quantity');
            $table->datetime('shipping_date');
            $table->datetime('delivery_date');
            $table->string('status')->default('pending'); // Added status column
            $table->foreignId('batch_id')->constrained('food_batches')->onDelete('cascade');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('distributions');
    }
};