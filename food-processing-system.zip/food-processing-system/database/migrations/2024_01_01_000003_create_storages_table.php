<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('storages', function (Blueprint $table) {
            $table->id();
            $table->string('location');
            $table->decimal('capacity', 10, 2);
            $table->decimal('temperature', 5, 2);
            $table->decimal('humidity', 5, 2);
            $table->string('status')->default('active'); // Added status column
            $table->foreignId('batch_id')->constrained('food_batches')->onDelete('cascade');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('storages');
    }
};