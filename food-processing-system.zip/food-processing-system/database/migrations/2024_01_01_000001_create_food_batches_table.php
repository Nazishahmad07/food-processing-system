<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('food_batches', function (Blueprint $table) {
            $table->id();
            $table->string('batch_number')->unique();
            $table->string('name');  // Added name field
            $table->string('category');  // Added category field
            $table->string('product_name');
            $table->integer('quantity');
            $table->datetime('production_date');
            $table->datetime('processing_date');  // Added processing date
            $table->string('quality_grade');  // Added quality grade
            $table->datetime('expiry_date');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('food_batches');
    }
};